socialfaq

Before run, you need install MySQLdb and flask.

use 'python run.py' to run.













Don't care this.
dev_server.py --mysql=1162234221@qq.com:123456asdf@w.rdc.sae.sina.com.cn:3307
